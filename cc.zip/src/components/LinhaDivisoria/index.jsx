import Style from './style.module.css'

export default function LinhaDivisoria() {
    return (
        <div className={Style.container}>
            <div className={Style.linhadivisoria}>
                <h4>Nome</h4>
                <h4>Data da última alteração</h4>
            </div>
        </div>

    )
}