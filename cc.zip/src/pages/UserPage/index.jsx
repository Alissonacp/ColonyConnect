export default function UserPage() {
    return (
        <div>
            <h1>Perfil de usuário</h1>
        </div>
    );
}