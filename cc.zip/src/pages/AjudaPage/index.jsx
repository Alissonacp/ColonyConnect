export default function AjudaPage() {
  return (
    <div>
      <h1>Ajuda</h1>
    </div>
  )};